import { createClient } from "@supabase/supabase-js";
import "./style.css";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const configured = Boolean(SUPABASE_URL && SUPABASE_KEY);
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;
const app = document.querySelector("#app");

let user = null, profile = null, activeClass = null, films = [], members = [], myVote = null;
let notice = "";

const esc = (s="") => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const initials = s => (s || "?").trim().slice(0,2).toUpperCase();

function shell(content) {
  app.innerHTML = `<header class="topbar"><a class="brand" href="#"><span class="brand-mark">C</span>CINE<span>PODIO</span></a><div class="top-actions">${user ? `<span class="user-chip">${esc(profile?.nickname || user.email)}</span><button class="btn btn-quiet" id="logout">Esci</button>` : ""}</div></header>
  <main>${notice ? `<div class="notice">${esc(notice)}</div>` : ""}${content}</main>
  <footer>Un film alla volta. Un podio alla volta. <span>✦</span></footer>`;
  document.querySelector("#logout")?.addEventListener("click", async () => { await supabase.auth.signOut(); user=null; profile=null; render(); });
}
function renderSetup() {
  shell(`<section class="hero"><div class="eyebrow">IL CLUB DEI CINEFILI</div><h1>Il cinema è<br><em>una questione</em><br>di punti di vista.</h1><p>Proponi un film, vota il podio della classe e scopri quale pellicola conquista tutti.</p></section>
  <section class="panel setup"><h2>Prima di iniziare</h2><p>Collega il progetto a Supabase per attivare accessi email, classi e votazioni condivise.</p><ol><li>Crea un progetto gratuito su Supabase.</li><li>Esegui lo script <code>supabase/schema.sql</code> nell'SQL Editor.</li><li>Copia URL e chiave anon in un file <code>.env</code>.</li><li>Avvia il progetto con <code>npm install</code> e <code>npm run dev</code>.</li></ol><p class="muted">Le istruzioni complete sono nel README.</p></section>`);
}
function renderAuth() {
  shell(`<section class="auth-layout"><div class="hero"><div class="eyebrow">BENVENUTO AL CINECLUB</div><h1>La tua prossima<br><em>ossessione</em><br>cinematografica.</h1><p>Entra con la tua email. Ti invieremo un link di accesso, senza password.</p></div>
  <form id="login" class="panel auth-form"><div class="eyebrow">ACCESSO MEMBRI</div><h2>Entra in sala.</h2><label for="email">Indirizzo email</label><input id="email" type="email" placeholder="nome@email.com" required autocomplete="email"><button class="btn btn-primary" type="submit">Ricevi il link di accesso <span>↗</span></button><small>Usando il servizio accetti di partecipare alle votazioni della tua classe.</small></form></section>`);
  document.querySelector("#login").addEventListener("submit", async e => {
    e.preventDefault(); notice="";
    const email = document.querySelector("#email").value.trim();
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: location.origin } });
    notice = error ? error.message : "Link inviato! Controlla la tua casella email e apri il messaggio per entrare.";
    renderAuth();
  });
}
async function loadProfile() {
  const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
  profile = data;
}
function renderNickname() {
  shell(`<section class="panel narrow"><div class="eyebrow">NUOVO MEMBRO</div><h1>Come ti<br><em>chiamiamo?</em></h1><p>Scegli un nickname che comparirà accanto ai tuoi film proposti.</p><form id="nickname"><label for="nick">Il tuo nickname</label><input id="nick" maxlength="24" minlength="2" required placeholder="Es. Kubrickiano"><button class="btn btn-primary">Entra nel cineclub ↗</button></form></section>`);
  document.querySelector("#nickname").addEventListener("submit", async e => {
    e.preventDefault();
    const nickname = document.querySelector("#nick").value.trim();
    const { error } = await supabase.from("profiles").upsert({id:user.id,nickname});
    notice = error ? (error.code==="23505" ? "Nickname già utilizzato: scegline un altro." : error.message) : "";
    await loadProfile(); render();
  });
}
async function loadClasses() {
  const { data, error } = await supabase.from("class_members").select("class_id, classes(id,name,join_code)");
  if (error) { notice=error.message; return []; }
  return (data || []).map(x=>x.classes).filter(Boolean);
}
function renderHome(classes) {
  shell(`<section class="hero compact"><div class="eyebrow">LA TUA COMMUNITY</div><h1>Buona visione,<br><em>${esc(profile.nickname)}.</em></h1><p>Ogni grande classifica comincia da una grande discussione.</p></section>
  <section class="home-grid"><div class="panel"><div class="eyebrow">LE TUE CLASSI</div><h2>Entra in una sala.</h2>${classes.length ? classes.map(c=>`<button class="class-row" data-class="${c.id}"><span><b>${esc(c.name)}</b><small>Codice: ${esc(c.join_code)}</small></span><span>→</span></button>`).join("") : `<p class="muted">Non fai ancora parte di una classe.</p>`}</div>
  <div class="panel"><div class="eyebrow">NUOVA COMMUNITY</div><h2>Crea una classe.</h2><form id="create-class"><label>Nome della classe</label><input name="name" maxlength="60" required placeholder="Es. Cineforum 3B"><button class="btn btn-primary">Crea classe ↗</button></form><hr><h2>Hai un codice?</h2><form id="join-class"><label>Codice di invito</label><input name="code" maxlength="12" required placeholder="ABC123"><button class="btn btn-secondary">Unisciti alla classe</button></form></div></section>`);
  document.querySelectorAll("[data-class]").forEach(b=>b.addEventListener("click",()=>openClass(b.dataset.class)));
  document.querySelector("#create-class").addEventListener("submit", createClass);
  document.querySelector("#join-class").addEventListener("submit", joinClass);
}
async function createClass(e) {
  e.preventDefault(); const name = new FormData(e.target).get("name").trim();
  const { data, error } = await supabase.from("classes").insert({name,created_by:user.id}).select().single();
  if (error) { notice=error.message; render(); return; }
  await render(); openClass(data.id);
}
async function joinClass(e) {
  e.preventDefault(); const code = new FormData(e.target).get("code").trim().toUpperCase();
  const { data, error } = await supabase.rpc("join_class_by_code",{p_code:code});
  if (error || !data) { notice="Codice non valido o impossibile entrare nella classe."; render(); return; }
  notice=""; await render(); openClass(data);
}
async function openClass(id) {
  const {data: cls, error} = await supabase.from("classes").select("*").eq("id",id).single();
  if (error) { notice=error.message; render(); return; }
  activeClass=cls;
  const [{data:f},{data:m},{data:v}] = await Promise.all([
    supabase.from("films").select("*, profiles(nickname)").eq("class_id",id).order("created_at"),
    supabase.from("class_members").select("user_id, profiles(nickname)").eq("class_id",id),
    supabase.from("votes").select("*").eq("class_id",id).eq("user_id",user.id).maybeSingle()
  ]);
  films=f||[]; members=m||[]; myVote=v||null;
  renderClass();
}
function getResults() {
  const scores = Object.fromEntries(films.map(f=>[f.id,0]));
  (window.__allVotes || []).forEach(v=>{ if(v.first_film_id) scores[v.first_film_id]+=3; if(v.second_film_id) scores[v.second_film_id]+=2; if(v.third_film_id) scores[v.third_film_id]+=1; });
  return films.map(f=>({...f,score:scores[f.id]||0})).sort((a,b)=>b.score-a.score || a.title.localeCompare(b.title));
}
async function renderClass() {
  const {data:allVotes} = await supabase.from("votes").select("first_film_id,second_film_id,third_film_id").eq("class_id",activeClass.id);
  window.__allVotes=allVotes||[];
  const own = films.filter(f=>f.user_id===user.id);
  const eligible = films.filter(f=>f.user_id!==user.id);
  const results=getResults(), max=Math.max(1,...results.map(f=>f.score));
  const podium = results.slice(0,3);
  const hasVoted = Boolean(myVote);
  shell(`<div class="class-head"><button class="back" id="back">← Tutte le classi</button><div class="eyebrow">SALA PRIVATA · ${esc(activeClass.join_code)}</div><h1>${esc(activeClass.name)}</h1><p>${members.length} membri <span>·</span> ${films.length} film in gara</p></div>
  <nav class="tabs"><button class="tab active" data-tab="films">La selezione</button><button class="tab" data-tab="vote">Il tuo podio</button><button class="tab" data-tab="results">Classifica</button></nav>
  <section id="tab-films" class="tab-content"><div class="section-title"><div><div class="eyebrow">PROPOSTE DELLA CLASSE</div><h2>La selezione ufficiale.</h2></div><span class="count">${films.length} FILM</span></div>
  ${own.length ? `<div class="notice subtle">Hai proposto <b>${esc(own[0].title)}</b>. Puoi votare solo film proposti dagli altri membri.</div>` : `<form id="add-film" class="panel add-film"><div class="eyebrow">LA TUA PROPOSTA</div><h3>Quale film porti in sala?</h3><div class="form-row"><div><label>Titolo del film</label><input name="title" required maxlength="120" placeholder="Titolo originale"></div><div><label>Anno (facoltativo)</label><input name="year" type="number" min="1888" max="2100" placeholder="2024"></div></div><div class="form-row"><div><label>Regista (facoltativo)</label><input name="director" maxlength="100" placeholder="Nome del regista"></div><button class="btn btn-primary align-end">Proponi film ↗</button></div></form>`}
  <div class="film-grid">${films.length ? films.map((f,i)=>`<article class="film-card"><div class="film-number">${String(i+1).padStart(2,"0")}</div><div class="film-info"><h3>${esc(f.title)}</h3><p>${[f.year, f.director].filter(Boolean).map(esc).join(" · ") || "Scheda senza dettagli"}</p><small>Proposto da ${esc(f.profiles?.nickname||"Membro")}</small></div>${f.user_id===user.id?`<span class="yours">TUO</span>`:""}</article>`).join("") : `<p class="muted">Ancora nessun film. Rompi il ghiaccio con la prima proposta!</p>`}</div></section>
  <section id="tab-vote" class="tab-content hidden"><div class="section-title"><div><div class="eyebrow">VOTAZIONE PERSONALE</div><h2>Componi il podio.</h2></div><span class="count">3 · 2 · 1 PUNTI</span></div>
  ${own.length ? `<p class="notice subtle">I tuoi film sono esclusi automaticamente. Nessuno può assegnare punti alla propria proposta.</p>`:""}
  ${hasVoted ? `<div class="notice">Hai già votato. La tua scelta è registrata e non può essere modificata.</div>`:""}
  ${eligible.length<3 ? `<div class="panel"><p>Servono almeno 3 film proposti dagli altri membri prima di poter votare.</p></div>` : hasVoted ? `<div class="panel"><h3>Il tuo podio</h3>${[myVote.first_film_id,myVote.second_film_id,myVote.third_film_id].map((id,i)=>{const f=films.find(x=>x.id===id);return `<div class="vote-summary"><b>${["🥇","🥈","🥉"][i]} ${i+1}° posto</b><span>${esc(f?.title||"Film non disponibile")}</span></div>`}).join("")}</div>` : `<form id="vote-form" class="panel vote-form"><p class="muted">Crea il tuo podio personale scegliendo tre film diversi tra quelli proposti dagli altri membri: assegna il 1° posto a un film, il 2° a un altro e il 3° a un terzo. Ogni podio contribuirà alla classifica finale.</p>${[1,2,3].map((n)=>`<label class="rank-label"><span class="medal">${["🥇","🥈","🥉"][n-1]}</span><span>${n}° posto</span><select name="rank${n}" required><option value="">Seleziona un film…</option>${eligible.map(f=>`<option value="${f.id}">${esc(f.title)} — ${esc(f.profiles?.nickname||"")}</option>`).join("")}</select></label>`).join("")}<button class="btn btn-primary">Conferma il mio podio ↗</button></form>`}</section>
  <section id="tab-results" class="tab-content hidden"><div class="section-title"><div><div class="eyebrow">RISULTATI FINALI</div><h2>Il podio della classe.</h2></div><span class="count">${window.__allVotes.length} VOTI</span></div>
  <div class="panel chart-panel"><div class="podium">${podium.map((f,i)=>`<div class="podium-item p${i+1}"><div class="podium-medal">${["🥇","🥈","🥉"][i]}</div><b>${esc(f.title)}</b><small>${f.score} punti</small></div>`).join("")}</div>
  <div class="bars">${results.map((f,i)=>`<div class="bar-row"><div class="bar-label"><span>${i+1}. ${esc(f.title)}</span><b>${f.score}</b></div><div class="bar-track"><div class="bar-fill" style="width:${f.score/max*100}%"></div></div></div>`).join("")}</div><p class="muted footnote">La classifica finale nasce dalla somma dei podi personali: ogni 1° posto assegna 3 punti, ogni 2° posto 2 punti e ogni 3° posto 1 punto. I film proposti da chi vota sono esclusi dal suo podio.</p></div></section>`);
  document.querySelector("#back").addEventListener("click",()=>render());
  document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tab-content").forEach(x=>x.classList.toggle("hidden",x.id!==`tab-${b.dataset.tab}`));}));
  document.querySelector("#add-film")?.addEventListener("submit", addFilm);
  document.querySelector("#vote-form")?.addEventListener("submit", submitVote);
}
async function addFilm(e) {
  e.preventDefault(); const d=new FormData(e.target);
  const payload={class_id:activeClass.id,user_id:user.id,title:d.get("title").trim(),year:d.get("year")?Number(d.get("year")):null,director:d.get("director").trim()||null};
  const {error}=await supabase.from("films").insert(payload);
  if(error) notice=error.code==="23505"?"Hai già proposto un film in questa classe.":error.message;
  await openClass(activeClass.id);
}
async function submitVote(e) {
  e.preventDefault(); const d=new FormData(e.target);
  const ids=[d.get("rank1"),d.get("rank2"),d.get("rank3")];
  if(new Set(ids).size!==3) { notice="Scegli tre film diversi."; renderClass(); return; }
  const {error}=await supabase.from("votes").insert({class_id:activeClass.id,user_id:user.id,first_film_id:ids[0],second_film_id:ids[1],third_film_id:ids[2]});
  if(error) notice=error.message.includes("own")?"Non puoi votare un film che hai proposto.":error.message;
  await openClass(activeClass.id);
}
async function render() {
  notice="";
  if(!configured) return renderSetup();
  const {data}=await supabase.auth.getSession();
  user=data.session?.user||null;
  if(!user) return renderAuth();
  await loadProfile();
  if(!profile) return renderNickname();
  const classes=await loadClasses();
  renderHome(classes);
}
supabase?.auth.onAuthStateChange(async (_event,session)=>{user=session?.user||null; await render();});
render();
