# CinePodio

Web app per cineclub/classi: accesso passwordless via email, nickname, creazione o ingresso in una classe tramite codice, una proposta di film per membro e votazione del podio.

## Regole di voto implementate
- Ogni membro può proporre **un solo film per classe**.
- Ogni membro compone **un podio personale di tre film distinti**, scelti tra quelli proposti dagli altri membri: assegna un 1°, un 2° e un 3° posto.
- Il podio personale assegna 3 punti al film al 1° posto, 2 punti al 2° e 1 punto al 3°.
- La classifica finale è la somma dei punti ricevuti da tutti i podi personali.
- I film proposti dall'utente che sta votando non appaiono tra le scelte.
- La regola è verificata anche nel database con un trigger, non solo nell'interfaccia.
- La classifica aggrega i punti e mostra podio e barre proporzionali.

## Avvio locale

1. Crea un progetto su [Supabase](https://supabase.com/).
2. Nel pannello Supabase apri **SQL Editor** e incolla/esegui `supabase/schema.sql`.
3. In **Authentication → URL Configuration**, imposta `http://localhost:5173` come Site URL e aggiungilo ai Redirect URLs.
4. In **Authentication → Providers → Email**, abilita l'accesso email con OTP/magic link.
5. Copia `.env.example` in `.env` e inserisci Project URL e anon/publishable key (mai la service-role key).
6. Installa e avvia:

   ```bash
   npm install
   npm run dev
   ```

7. Apri l'indirizzo mostrato da Vite, normalmente `http://localhost:5173`.

## Pubblicazione
Puoi pubblicare il frontend su Vercel o Netlify collegando il repository Git. Imposta le stesse variabili `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` nelle variabili d'ambiente del provider e aggiungi il dominio pubblico agli URL consentiti in Supabase Auth.

## Nota sul flusso
La prima persona crea una classe e condivide il codice d'invito. Gli altri si registrano con email, scelgono un nickname e inseriscono quel codice. Ogni utente propone il proprio film; quando sono disponibili almeno tre film degli altri membri, può inviare il proprio podio. La scheda Classifica mostra il punteggio corrente.

## Prima di un uso pubblico
Questa è una base funzionante da configurare e collaudare, non un servizio già pubblicato. Prima del lancio verifica email SMTP/deliverability, domini e redirect di produzione, privacy policy/consenso, protezione anti-abuso e test con più account. Il codice d'invito dà accesso alla classe: condividilo solo con i partecipanti.
