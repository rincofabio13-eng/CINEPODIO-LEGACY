-- CinePodio: schema + policy di sicurezza.
-- Eseguire una volta nel SQL Editor del progetto Supabase.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null unique check (char_length(nickname) between 2 and 24),
  created_at timestamptz not null default now()
);

create table if not exists public.classes (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 60),
  join_code text not null unique default upper(substr(encode(gen_random_bytes(6),'hex'),1,8)),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.class_members (
  class_id uuid not null references public.classes(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (class_id,user_id)
);

-- Chi crea la classe ne diventa automaticamente membro.
create or replace function public.add_creator_to_class()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.class_members(class_id,user_id) values(new.id,new.created_by);
  return new;
end; $$;
drop trigger if exists classes_add_creator on public.classes;
create trigger classes_add_creator after insert on public.classes
for each row execute function public.add_creator_to_class();

-- Ingresso tramite codice: il codice non viene esposto in una query pubblica.
create or replace function public.join_class_by_code(p_code text)
returns uuid language plpgsql security definer set search_path=public
as $$
declare v_class_id uuid;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select id into v_class_id from public.classes
    where join_code=upper(trim(p_code));
  if v_class_id is null then raise exception 'invalid_join_code'; end if;
  insert into public.class_members(class_id,user_id)
    values(v_class_id,auth.uid()) on conflict do nothing;
  return v_class_id;
end; $$;
grant execute on function public.join_class_by_code(text) to authenticated;

create table if not exists public.films (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  year integer check (year is null or year between 1888 and 2100),
  director text,
  created_at timestamptz not null default now(),
  unique (class_id,user_id),
  unique (id,class_id)
);

create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  first_film_id uuid not null,
  second_film_id uuid not null,
  third_film_id uuid not null,
  created_at timestamptz not null default now(),
  unique (class_id,user_id),
  foreign key (first_film_id,class_id) references public.films(id,class_id),
  foreign key (second_film_id,class_id) references public.films(id,class_id),
  foreign key (third_film_id,class_id) references public.films(id,class_id),
  check (first_film_id <> second_film_id and first_film_id <> third_film_id and second_film_id <> third_film_id)
);

create or replace function public.is_class_member(p_class_id uuid, p_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.class_members where class_id=p_class_id and user_id=p_user_id); $$;

-- Impedisce anche via API manipolate di votare film propri.
create or replace function public.validate_vote()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if new.user_id <> auth.uid() then raise exception 'user_mismatch'; end if;
  if not public.is_class_member(new.class_id,new.user_id) then raise exception 'not_class_member'; end if;
  if exists (
    select 1 from public.films f
    where f.id in (new.first_film_id,new.second_film_id,new.third_film_id)
      and f.user_id = new.user_id
  ) then raise exception 'own_film_not_allowed'; end if;
  return new;
end; $$;
drop trigger if exists votes_validate on public.votes;
create trigger votes_validate before insert or update on public.votes
for each row execute function public.validate_vote();

alter table public.profiles enable row level security;
alter table public.classes enable row level security;
alter table public.class_members enable row level security;
alter table public.films enable row level security;
alter table public.votes enable row level security;

create policy "profiles visible to authenticated" on public.profiles for select to authenticated using (true);
create policy "profile insert self" on public.profiles for insert to authenticated with check (id=auth.uid());
create policy "profile update self" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

create policy "class read by members" on public.classes for select to authenticated using (public.is_class_member(id));
create policy "class create authenticated" on public.classes for insert to authenticated with check (created_by=auth.uid());
create policy "member list visible to class" on public.class_members for select to authenticated using (public.is_class_member(class_id));
drop policy if exists "join class self" on public.class_members;
-- L’ingresso avviene esclusivamente tramite join_class_by_code().
create policy "films visible to members" on public.films for select to authenticated using (public.is_class_member(class_id));
create policy "one film per member" on public.films for insert to authenticated with check (user_id=auth.uid() and public.is_class_member(class_id));
create policy "votes visible to members" on public.votes for select to authenticated using (public.is_class_member(class_id));
create policy "one ballot per member" on public.votes for insert to authenticated with check (user_id=auth.uid() and public.is_class_member(class_id));

grant usage on schema public to authenticated;
grant select,insert,update on public.profiles to authenticated;
grant select,insert on public.classes to authenticated;
grant select,insert on public.class_members to authenticated;
grant select,insert on public.films to authenticated;
grant select,insert on public.votes to authenticated;
